/**
 * @file proj2.h
 * @author Jan Škrabal (xskrab12)-FIT
 * @brief IOS projekt 2 knihovna synchronizace (Building H2O)
 * @date 2022-03-23
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#ifndef PROJ2_LIB
#define PROJ2_LIB

#include <stdlib.h>             // size_t

#define ARG_COUNT 5             // počet očekávaných argumentů
#define TIME_MAX 1000           // maximální čas zdaný v parametrech času
#define OUTPUT_FILE "proj2.out" // jméno výstupního souboru


/**
 * @brief Struktura paměti
 * 
 */
typedef struct shmem {
    size_t id;                  // pořadí vykonávané činnosti, zvyšuje se při každém zápisu do souboru

    size_t count_o;             // počet kyslíků, zadaný parametren
    size_t count_h;             // počet vodíků, zadaný parametren

    size_t time_i;              // maximálí čas pro zařazení atomu do fronty
    size_t time_b;              // maximálí čas pro vytvoření jedné molekuly.

    size_t out_o;               // počet kyslíků zařazených na frontě
    size_t out_h;               // počet vodíků zařazených na frontě

    size_t molecule;            // počet vytvořených molekul vody
    size_t max_craete_molekules;// kolik procesů vytvoří molekuly vody

    int bar;                    // počítadlo pro průchod bariérou najednou
}shmem_t;

/**
 * @brief Struktura semaforů
 * 
 */
typedef struct semaphores {
    sem_t *mutex;               // semafor kritické sekce
    sem_t *queue_o;             // fronta kyslíků
    sem_t *queue_h;             // fronta vodíků
    sem_t *barrier;             // semafor bariéry
    sem_t *print;               // semafor pro výpis do souboru
    sem_t *molecule;            // semafor vytváření molekuly
    sem_t *molecule_done;       // semafor pro signalizaci dokončení vytváření molekuly
    sem_t *to_end;              // semafor pro práci s početem vytvořených molekul, prechod na vypouštení přebytečných atomů
    sem_t *end;                 // semafor pro uvolnění přebytečných atomů z front
}sems_t;


#endif // PROJ2_LIB
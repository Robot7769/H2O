/**
 * @file error.h
 * @author Jan Škrabal (xskrab12)-FIT
 * @brief IJC-DU1 B hlavičkový soubor vypisování error zpráv
 * @date 2022-02-22
 *
 * @copyright Copyright (c) 2022
 *
 */

#ifndef IJC_ERROR_LIB
#define IJC_ERROR_LIB

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h> // funkce s proměným počtem  argumentů

/**
 * @brief Píše chybovou hlášku na stderr ve formátu CHYBA: "text"
 * 
 * @param fmt první argument textu
 * @param ... další část textu, volitelný počet argumentů
 */
extern void warning_msg(const char *fmt, ...);

/**
 * @brief Píše chybovou hlášku na stderr ve formátu CHYBA: "text" a ukončí program s kódem EXIT_FAILURE
 * 
 * @param fmt první argument textu
 * @param ... další část textu, volitelný počet argumentů
 */
extern void error_exit(const char *fmt, ...);

#endif  // IJC_ERROR_LIB
/**
 * @file funkce.c
 * @author Jan Škrabal (xskrab12)-FIT
 * @brief IOS projekt 2 Funkce synchronizace (Building H2O)
 * @date 2022-03-23
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdbool.h>    // bool
#include <string.h>     // strlen()

#include <time.h>       // time() pro nastavování seadu funkce rand()

/**
 * @brief Funkce na validaci že řetězec obsahuje pouze číslice
 * 
 * @param ptr 
 * @return true 
 * @return false 
 */
bool is_number( char const *ptr) {
    for (size_t i = 0; i < strlen(ptr); i++) {
        if (!(ptr[i] >= '0' && ptr[i] <= '9')){
            return true;
        }
    }
    return false;
}

/**
 * @brief Nastavení proměních sdílené paměti
 * 
 * @param memory 
 */
void memory_setup(shmem_t *memory) {
    memory->out_o = 0;
    memory->out_h = 0;
    memory->molecule = 0;   
    memory->bar = -3;
}

/**
 * @brief Otevření a inicializace semaforů
 * 
 * @param sems  struktura semaforů
 * @return int  1 při chybě, 0 při uspěchu
 */
int sem_start(sems_t *sems) {
    sems->mutex = sem_open("/ios_proj2_H2O_mutex", O_CREAT | O_EXCL, 0666, 1);  // první volání sem_wait(sems->mutex); projde
    if (sems->mutex == SEM_FAILED) {
        return 1;
    }
    sems->queue_o = sem_open("/ios_proj2_H2O_queue_o", O_CREAT | O_EXCL, 0666, 0);  // fronta kyslíků
    if (sems->queue_o == SEM_FAILED) {
        return 1;
    }
    sems->queue_h = sem_open("/ios_proj2_H2O_queue_h", O_CREAT | O_EXCL, 0666, 0);  // fronta vodíků
    if (sems->queue_h == SEM_FAILED) {
        return 1;
    }
    sems->barrier = sem_open("/ios_proj2_H2O_barrier", O_CREAT | O_EXCL, 0666, 0);  // bariéra
    if (sems->barrier == SEM_FAILED) {
        return 1;
    }
    sems->print = sem_open("/ios_proj2_H2O_print", O_CREAT | O_EXCL, 0666, 1);  // první volání sem_wait(sems->print); projde
    if (sems->print == SEM_FAILED) {
        return 1;
    }
    sems->molecule = sem_open("/ios_proj2_H2O_molecule", O_CREAT | O_EXCL, 0666, 1);    // první volání sem_wait(sems->molecule); projde
    if (sems->molecule == SEM_FAILED) {
        return 1;
    }
    sems->molecule_done = sem_open("/ios_proj2_H2O_molecule_done", O_CREAT | O_EXCL, 0666, 1);   // první volání sem_wait(sems->molecule_done); projde
    if (sems->molecule_done == SEM_FAILED) {
        return 1;
    }
    sems->to_end = sem_open("/ios_proj2_H2O_to_end", O_CREAT | O_EXCL, 0666, 1);     // první volání sem_wait(sems->to_end); projde
    if (sems->to_end == SEM_FAILED) {
        return 1;
    }
    sems->end = sem_open("/ios_proj2_H2O_end", O_CREAT | O_EXCL, 0666, 0);      // volání sem_wait(sems->end); čeká na sem_post
    if (sems->end == SEM_FAILED) {
        return 1;
    }
    return 0;
}

/**
 * @brief výpočet kolik se dokáže vytvořit molekul vody
 * 
 * @param sems  struktura semaforů
 * @param mem   sdílená pamět
 * @return int  počet moleku který se dokáže vytvořit
 */
int cal_crate_molekule(sems_t sems,shmem_t *mem) {
    int molekules_max_conut;     // počet kolik se má vytvořit molekul vody  
    sem_wait(sems.mutex);
    /* 
    molekul vody se může vytvoři (počet vodíků)/2, pokud je dostatek kyslíků
    nebo počet kyslíků za předpokladu že je dostatek vodíků 
    m = (NH/2 > NO) ? NO : NH/2
    */
    mem->max_craete_molekules = mem->count_h/2;
    if (mem->max_craete_molekules > mem->count_o) {
        mem->max_craete_molekules = mem->count_o;
    }
    molekules_max_conut = mem->max_craete_molekules;
    //printf("vyrobím jenom %ld molekul vody\n", mem->max_craete_molekules);
    mem->max_craete_molekules = 3*(mem->max_craete_molekules);
    sem_post(sems.mutex);
    return molekules_max_conut;
}

/**
 * @brief Kontrola počtu procesů které vytvořili molekulu vody
 * 
 * @param sems  struktura semaforů
 * @param mem   sdílená pamět
 */
void process_control(sems_t sems,shmem_t *mem) {
    sem_wait(sems.to_end);
    mem->max_craete_molekules--;
    // pokud zavolání této funkce bylo poslední při poslední molekule se uvolní semafor pro vypuštění přebytečných atomů
    if (mem->max_craete_molekules == 0) {
        sem_post(sems.end);   
    }
    sem_post(sems.to_end);
}

/**
 * @brief Výpis textu do souboru
 * 
 * @param sems   struktura semaforů
 * @param mem    sdílená pamět 
 * @param output otevřený výstupní soubor
 * @param fmt    první argument textu
 * @param ...    další část textu, volitelný počet argumentů
 */
void print_out(sems_t sems,shmem_t *mem, FILE *output,const char *fmt, ...) {
    sem_wait(sems.print);       // semafor pro výpis, aby nedošlo k vícenásobnému zápisu do souboru
    mem->id +=1;                // číslo výpisu
    va_list(argumenty);         // list argumentů
    va_start(argumenty,fmt);
    fprintf(output, "%ld: ", mem->id);  // výpis čísla řádku
    fflush(output);             // vyprázdnění barfu pro zápis do souboru
    //fprintf(stdout, "%ld: ", mem->id); //* test
    vfprintf(output,fmt,argumenty);     // výpis čísla řádku
    fflush(output);             // vyprázdnění barfu pro zápis do souboru
    //vfprintf(stdout,fmt,argumenty); //* test
    va_end(argumenty);
    sem_post(sems.print);
}

/**
 * @brief Vytváření molekuly, signalizuje její vytvoření vodíkům a vypoští atomy tvořící tuto molekulu vody ven z bariéry
 * 
 * @param sems   struktura semaforů
 * @param mem    sdílená pamět 
 * @param output otevřený výstupní soubor
 * @param id     kolikátý kyslík volá funkci
 */
void molecul_creator(sems_t sems,shmem_t *mem, FILE *output, size_t id) {
    print_out(sems,mem, output,"O %d: creating molecule %d\n", id, mem->molecule);
    if (mem->time_b != 0) {
        usleep(rand() % (mem->time_b*1000));    // náhodný čas vytváření molekuly
    }
    print_out(sems,mem, output,"O %d: molecule %d created\n", id, mem->molecule);
    sem_post(sems.molecule_done);   // signalizuje prvnímu vodíku že společně vytvořili molekulu vody
    sem_post(sems.molecule_done);   // signalizuje druhému vodíku že společně vytvořili molekulu vody
    sem_wait(sems.molecule);
    (mem->bar)++;                   // počítání počtu prvků na bariéře
    //printf("bar: %d\n", mem->bar);
    if (mem->bar == 0 ) {
        sem_post(sems.barrier);     // uvolnení z bariéry
        sem_post(sems.barrier);
        sem_post(sems.barrier);
        mem->bar = -3;              // vynulování bariéry
    }
    sem_post(sems.molecule);
}

/**
 * @brief Funkce kyslíku
 * 
 * @param ido    číslo procesu kyslíku
 * @param sems   struktura semaforů
 * @param mem    sdílená pamět 
 * @param output otevřený výstupní soubor
 */
void oxygen(size_t ido, sems_t sems, shmem_t *mem, FILE *output) {
    srand(time(NULL) ^ (getpid()<<16));         // vytvoření náhodného semínka pro funkce rand()
    print_out(sems,mem, output,"O %d: started\n",ido);
    if (mem->time_i != 0) {
        usleep(rand() % (mem->time_i*1000));    // náhodný čas pro zařazení atomu do fronty
    }
    sem_wait(sems.mutex);
    mem->out_o +=1;
    print_out(sems,mem, output,"O %d: going to queue\n", ido);
    if (mem->out_h >= 2) {          // je dostatek atomů na vytvoření molekuly vody
        mem->molecule +=1;
        sem_post(sems.queue_h);     // vezmeme 2 vodíky z fronty 
        sem_post(sems.queue_h);
        mem->out_h -= 2;
        sem_post(sems.queue_o);     // a jeden kyslík
        mem->out_o -= 1;
    } else {
        sem_post(sems.mutex);
    }

    sem_wait(sems.queue_o);         // fronta kyslíků
    if (mem->max_craete_molekules == 0) {   // přebytečné kyslíky
        print_out(sems,mem,output, "O %d: not enough H\n", ido);
        sem_post(sems.mutex);
        exit(0);
    }
    molecul_creator(sems, mem, output, ido);    // tvoření molekuly

    sem_wait(sems.barrier);
    sem_post(sems.mutex);
    fclose(output);
}

/**
 * @brief Funkce vodíku
 * 
 * @param idh    číslo procesu vodíku
 * @param sems   struktura semaforů
 * @param mem    sdílená pamět 
 * @param output otevřený výstupní soubor
 */
void hydrogen(size_t idh, sems_t sems, shmem_t *mem, FILE *output) {
    srand(time(NULL) ^ (getpid()<<16));         // vytvoření náhodného semínka pro funkce rand()
    print_out(sems,mem, output,"H %d: started\n", idh);
    if (mem->time_i != 0) {
        usleep(rand() % (mem->time_i*1000));    // náhodný čas pro zařazení atomu do fronty
    }
    sem_wait(sems.mutex);
    mem->out_h +=1;
    print_out(sems,mem, output,"H %d: going to queue\n", idh);
    if (mem->out_h >= 2 && mem->out_o >= 1) {   // je dostatek atomů na vytvoření molekuly vody
        mem->molecule +=1;
        sem_post(sems.queue_h);     // vezmeme 2 vodíky z fronty 
        sem_post(sems.queue_h);
        mem->out_h -= 2;
        sem_post(sems.queue_o);     // a jeden kyslík
        mem->out_o -= 1;
    } else {
        sem_post(sems.mutex);
    }

    sem_wait(sems.queue_h);         // fronta vodíků
    if (mem->max_craete_molekules == 0) {   // přebytečné vodíky
        print_out(sems,mem,output, "H %d: not enough O or H\n", idh);
        sem_post(sems.mutex);
        exit(0);
    }
    //molecul_creator(sems, mem, output, 'H', idh, mem->molecule);
    print_out(sems,mem, output,"H %d: creating molecule %d\n", idh, mem->molecule);
    sem_wait(sems.molecule_done);   // čeká až kyslik vytvoří molekulu
    print_out(sems,mem, output,"H %d: molecule %d created\n", idh, mem->molecule);
    sem_wait(sems.molecule);
    (mem->bar)++;                   // počítání počtu prvků na bariéře
    // vypoští atomy tvořící tuto molekulu vody ven z bariéry
    if (mem->bar == 0 ) {
        sem_post(sems.barrier);     // uvolnení z bariéry
        sem_post(sems.barrier);
        sem_post(sems.barrier);
        mem->bar = -3;              // vynulování bariéry
    }
    sem_post(sems.molecule);

    sem_wait(sems.barrier);         // molekula čeká na bariéře
    fclose(output);
}

/**
 * @brief Odlinkování semaforů a jejich uzavření, vymazání sdílené paměti
 * 
 * @param sems   struktura semaforů
 * @param mem    sdílená pamět 
 */
void clean_seme_mem(sems_t *sems, shmem_t *mem) {
    sem_unlink("/ios_proj2_H2O_mutex");
    sem_close(sems->mutex);

    sem_unlink("/ios_proj2_H2O_queue_o");
    sem_close(sems->queue_o);

    sem_unlink("/ios_proj2_H2O_queue_h");
    sem_close(sems->queue_h);

    sem_unlink("/ios_proj2_H2O_barrier");
    sem_close(sems->barrier);

    sem_unlink("/ios_proj2_H2O_print");
    sem_close(sems->print);

    sem_unlink("/ios_proj2_H2O_molecule");
    sem_close(sems->molecule);

    sem_unlink("/ios_proj2_H2O_molecule_done");
    sem_close(sems->molecule_done);

    sem_unlink("/ios_proj2_H2O_to_end");
    sem_close(sems->to_end);

    sem_unlink("/ios_proj2_H2O_end");
    sem_close(sems->end);
   
    munmap(mem, sizeof(shmem_t));
}

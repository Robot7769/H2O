/**
 * @file proj2.c
 * @author Jan Škrabal (xskrab12)-FIT
 * @brief IOS projekt 2 synchronizace (Building H2O)
 * @date 2022-03-23
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>

#include <semaphore.h>  // semafory

#include <sys/mman.h>   // sdílená paměť
#include <fcntl.h>

#include <sys/wait.h>   // čekání na neukončené procesy
#include <unistd.h>     // pid_t

#include "error.h"      // výpis chybových hlášek, error_exit()

#include "proj2.h"      // struktury paměti a semaforů
#include "funkce.c"     // funkce pro proj2 (projekt H2O)


int main(int argc, char const *argv[]) {
    // kontrola počtu argumentů
    if (argc != ARG_COUNT) {
        error_exit("Nesprávný počet argumentů!\n");
    }
    // validace že jsou všechny zadané paramentry čísla
    for (int i = 1; i < ARG_COUNT; i++) {
        if (is_number(argv[i])) {
            error_exit("Argument %d není celé kladné číslo\n", i);
        }
    }
    // vytvoření sdílené paměti
    shmem_t *mem = mmap(NULL, sizeof(shmem_t),PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS ,-1,0);
    if (mem == MAP_FAILED) {
        error_exit("Nepodařilo se vytnořit sdílenou paměť\n");
    }
    
    memory_setup(mem);

    sems_t sems;    // vytvoření struktury semaforů
    
    if (sem_start(&sems)) {             // spouštení semaforů 
        clean_seme_mem(&sems, mem);     // čištení semaforů a paměti
        error_exit("Semafor se neotevřel\n");
    }

    // argument 1 počet kyslíků
    mem->count_o = atoi(argv[1]);
    // argument 2 počet vodíků
    mem->count_h = atoi(argv[2]);
    // argument 3 čas čekání na zařazení do fronty
    mem->time_i = atoi(argv[3]);
    if (mem->time_i > TIME_MAX) {
        clean_seme_mem(&sems, mem);
        error_exit("TI není v rozsaho 0<=TI<=1000\n");
    }
    // argument 4 čas vytváření molekul
    mem->time_b = atoi(argv[4]);
    if (mem->time_b > TIME_MAX) {
        clean_seme_mem(&sems, mem);
        error_exit("TB není v rozsaho 0<=TB<=1000\n");
    }
    // otevření souboru pro zápis
    FILE *output = fopen(OUTPUT_FILE,"w");
    if (output == NULL) {
        clean_seme_mem(&sems, mem);
        error_exit("Nepodařilo se otevřít soubor pro zápis\n");
    }
    // počet kolik se má vytvořit molekul vody 
    int molekules_max_conut = cal_crate_molekule(sems, mem);
    // kontrola počtu molekul
    if (molekules_max_conut == 0) {
        sem_post(sems.end);     // Nevytvoří se žádná molekula takže se musí uvolit přebytečné procesy
    }
    
    pid_t process[mem->count_o + mem->count_h];     //pole PID proceců
    for (size_t i = 0; i < (mem->count_o + mem->count_h); i++) {
        pid_t pid = fork();                         //vytváření procesů
        if (pid == 0) {
            // proces dítěte
            if (i < mem->count_o) {
                //! funkce kyslík
                oxygen(i+1,sems, mem, output);
                process_control(sems,mem);
                exit(0);    // ukončení procesu
            } else {
                //! funkce vodík
                hydrogen(i-mem->count_o+1,sems, mem, output);
                process_control(sems,mem);
                exit(0);    // ukončení procesu
            }
            
        } else if (pid < 0) {
            // nepodařilo se vytvořít proces, nastala chyba
            for (size_t j = 0; j < i; j++) {
                kill(process[j],SIGKILL);       // ukončuje předchozí procesy při chybě
            }
            
            clean_seme_mem(&sems, mem);
            fclose(output);
            error_exit("Nepodařilo se otevřít proces\n");
        } else {
            process[i] = pid;   // uložení PID do pole
        }

    }

    // semafor čeká na poslední proces, který vytvořil molekulu
    sem_wait(sems.end);
    // uvolnění přebytečných atomů vodíků z fronty
    for (size_t i = (mem->count_h -2*molekules_max_conut); i > 0; i--) {
        sem_post(sems.queue_h);
    }
    // uvolnění přebytečných atomů kyslíku z fronty
    for (size_t i = mem->count_o - molekules_max_conut; i > 0; i--) {
        sem_post(sems.queue_o);
    }
    // čekání až zbívající procesy dojdou na frontu a projdou přes ni 
    for (size_t i = 0; i < (mem->count_o + mem->count_h); i++) {
        waitpid(process[i],NULL,0);
    }
    // vymazání paměti a uvolnění semaforů
    clean_seme_mem(&sems, mem);
    fclose(output);
    return 0;
}
